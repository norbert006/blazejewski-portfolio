package uk.ac.rhul.cs2800;

/**
 * This class defines the javafx pieces.
 * 
 * @author Norbert Blazejewski
 *
 */
public class View {

}
