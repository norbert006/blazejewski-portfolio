package uk.ac.rhul.cs2800;

/**
 * This enum represents two different operations type that a calculator can use, infix (standard
 * calculator) or postfix (Reverse Polish Calculator).
 * 
 * @author Norbert Blazejewski
 *
 */
public enum OpType {
  INFIX, POSTFIX;
}
