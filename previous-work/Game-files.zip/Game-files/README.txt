CodeSkulptor link: https://py3.codeskulptor.org/#user306_6YWIywufSOUEFP8_0.py

The raw game file is also present.

To start the game, "run" it inside your code editor. This should bring up the game window.